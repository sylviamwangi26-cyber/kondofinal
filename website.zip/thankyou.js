// Redirect user back to contact form if button clicked
document.getElementById("back-btn").addEventListener("click", () => {
    window.location.href = "contactus.html";
});
